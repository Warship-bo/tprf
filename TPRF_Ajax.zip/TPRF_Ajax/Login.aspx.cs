﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Drawing;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        { txtUserName.Focus(); }
        lblMessage.Visible = false;
    }
    protected void btn_Click(object sender, CommandEventArgs e)
    {
        string btnID = ((Button)sender).ID.Trim();
        switch (btnID.Trim().ToLower())
        {
            case "btnlogin":
                object obj = DBTran.IsLogin(txtUserName.Text.Trim(), txtPassword.Text.Trim());
                if (obj.GetType().Equals(typeof(DataSet)))
                {
                    GetSession((DataSet)obj);
                    Response.Redirect("Home.aspx");
                }
                else
                {
                    lblMessage.Visible = true;
                    lblMessage.ForeColor = Color.Red;
                    switch (obj.ToString().Trim())
                    {
                        case "-1":
                            lblMessage.Text = "Wrong Password!";
                            break;
                        case "0":
                            lblMessage.Text = "UserName Not Exists!";
                            break;
                    }
                }
                break;
            case "btnexit":
                //Response.Write("<script language=javascript>window.opener=null;window.close();</script>");
                ClientScript.RegisterStartupScript(this.GetType(), "close", "<script language='javascript'>window.opener=null;window.close();</script>");
                break;
        }
    }
    private void GetSession(DataSet ds)
    {
        Session["UserID"] = ds.Tables[0].Rows[0]["UserID"].ToString();
        Session["UserName"] = ds.Tables[0].Rows[0]["UserName"].ToString();
        Session["Password"] = ds.Tables[0].Rows[0]["UserPwd"].ToString();
        Session["Name"] = ds.Tables[0].Rows[0]["ChineseName"].ToString();
        Session["Shift"] = ds.Tables[0].Rows[0]["UserShift"].ToString();
        Session["RoleFlag"] = ds.Tables[0].Rows[0]["UserRole"].ToString();
        Session["Title"] = ds.Tables[0].Rows[0]["UserTitle"].ToString();
        Session["Email"] = ds.Tables[0].Rows[0]["Email"].ToString();
        Session["Role"] = ds.Tables[0].Rows[0]["RoleName"].ToString();
        Session["GroupID"] = ds.Tables[0].Rows[0]["UserGroup"].ToString();
        Session["Group"] = ds.Tables[0].Rows[0]["GroupName"].ToString();
    }

}
