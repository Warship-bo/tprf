﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            lblCurrentUser.Text = Session["UserName"].ToString();
            if (!IsPostBack)
            {
                dgList.Attributes.Add("style", "word-wrap:break-word; word-break:break-all;"); 
                dgDataBind();
            }
        }
        else
        { Response.Redirect("Login.aspx"); }
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }
    protected void lbIndex_Click(object sender, EventArgs e)
    {
        Response.Redirect("Index.aspx");
    }
    protected void lbDefault_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    protected void dgList_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
    {
        dgList.CurrentPageIndex = e.NewPageIndex;
        dgDataBind();
    }

    private void dgDataBind()
    {
        DataSet ds = DBTran.TPRFList();
        dgList.DataSource = ds;
        dgList.DataBind();
    }
    protected void dgList_ItemCommand(object source, DataGridCommandEventArgs e)
    {
        if (e.CommandName.Trim().Equals("BuyOff"))
        {
            string strID = e.Item.Cells[1].Text.ToString().Trim();
            DBTran.BuyOff(strID);
        }
        dgDataBind();
    }
    protected void dgList_ItemDataBound(object sender, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            if (e.Item.Cells[9].Text.Trim().Equals("Completed"))
            {
                e.Item.Cells[0].Visible = true;//.Attributes.Add("style", "display:block"); 
            }
            else
            {
                e.Item.Cells[10].Visible = false;//.Attributes.Add("style", "display:none"); 
            }
        }
    }
}
